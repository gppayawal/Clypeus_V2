package com.example.gpepayawal.v2;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TimePicker;
import android.widget.Toast;

import com.hypertrack.lib.HyperTrack;
import com.hypertrack.lib.callbacks.HyperTrackCallback;
import com.hypertrack.lib.models.ErrorResponse;
import com.hypertrack.lib.models.SuccessResponse;
import com.hypertrack.lib.models.User;
import com.hypertrack.lib.models.UserParams;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void login(View view){
        Toast.makeText(this, "inside login()", Toast.LENGTH_SHORT).show();

        UserParams userParams = new UserParams().setName("pau")
                .setPhone("2821806")
                .setPhoto("emergency_contacts.png")
                .setLookupId("2821806");

        Toast.makeText(this, "Hello, " + userParams.getName(), Toast.LENGTH_SHORT).show();

        // This API will create a new user only if none exists already for the given lookup_id
        HyperTrack.getOrCreateUser(userParams, new HyperTrackCallback() {
            @Override
            public void onSuccess(@NonNull SuccessResponse response) {
                if (response.getResponseObject() != null) {
                    User user = (User) response.getResponseObject();
                    // Handle user_id, if needed
                    String userId = user.getId();

                    //Toast.makeText(this, userId, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onError(@NonNull ErrorResponse errorResponse) {
                // Handle createUser error here
                //Toast.makeText(this, errorResponse.getErrorMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
